﻿#include <iostream> 
#include <unordered_map> 
#include <string>
#include <sstream>
#include <fstream>
#include <vector>
#include "que.h"
using namespace std; 

void print(unordered_map <string, unordered_map<string, unordered_map < string, string>>>&stadium,vector<string>&blocks,vector<string>&rows,int col_num, ofstream &out){//print the stadium unordered map

	out << endl;
	for(int i=0;i<blocks.size();i++){
		out<<blocks[i]<<endl;
		out<<"~~~~~~~"<<endl;
		for(int a=0;a<rows.size();a++){
			out<<rows[a]<<" : ";
			for(int b=0;b<col_num;b++){
				out<<stadium[blocks[i]][rows[a]][to_string(b)];
				if(b!=col_num){
					out<<" ";
				}
			}
			out<<endl;
		}
		out<<"======="<<endl<<endl;
	}
}

bool get_seat (string name,unordered_map <string, vector<string>>&reservations, ofstream &out){

	if(!(reservations.find(name) == reservations.end())){//look if name occurs in reservation unordered map
		out<<"Found that "<<name<<" "<<"has a reservation in "<<reservations[name][0]<<" "<<reservations[name][1]<<"-"<<reservations[name][2]<<endl;
		return true;
	}
	else{
		out<<"There is no reservation made for "<<name<<"!"<<endl;
		return false;
	}
}

void reserve_seat(unordered_map <string, unordered_map<string, unordered_map < string, string>>>&stadium,string name,string block,string row,string col,unordered_map <string, vector<string>>&reservations,unordered_map <string, que>&heaplist, ofstream &out){

	if(reservations.find(name) == reservations.end()){//look if name occurs in reservation unordered map
		if(stadium[block][row][col]=="---"){//if index in stadium is ---
			stadium[block][row][col]=name.substr(0,3);//fill it with first three letters of name
			reservations[name];//fill reservation name with name string
			reservations[name].resize(3);//resice vector
			reservations[name][0]=block;//fill block data
			reservations[name][1]=row;//fill row data
			reservations[name][2]=col;//fill col data
			heaplist[row].increase(block);//call increase function
			out<<name<<" has reserved "<<block<<" "<<row<<"-"<<col<<endl;
			return;

		}
		else{
			out<<name<<"could not reserve a seat!"<<endl;
			return;
		}
	}
	else{
		out<<name<<"could not reserve a seat!"<<endl;
		return;
	}
}

void reserve_seat_by_row(string name,string row,unordered_map <string, unordered_map<string, unordered_map < string, string>>>&stadium,unordered_map <string, vector<string>>&reservations,unordered_map <string, que>&heaplist,int colnum, ofstream &out){
	int temp;
	bool flag=false;
	string block=heaplist[row].get_min();
	for(temp=0;temp<colnum;temp++){
		if(stadium[block][row][to_string(temp)]=="---"){
			flag=true;
			break;
		}
	}
	if(flag){
		if(reservations.find(name) == reservations.end()){//look if name occurs in reservation unordered map
			if(stadium[block][row][to_string(temp)]=="---"){//if index in stadium is ---
				stadium[block][row][to_string(temp)]=name.substr(0,3);//fill it with first three letters of name
				reservations[name];//fill reservation name with name string
				reservations[name].resize(3);//resice vector
				reservations[name][0]=block;//fill block data
				reservations[name][1]=row;//fill row data
				reservations[name][2]=to_string(temp);//fill col data
				heaplist[row].increase(block);//call increase function
				out<<name<<" has reserved "<<block<<" "<<row<<"-"<<to_string(temp)<<" by emptiest block"<<endl;
				return;
			}
		}
		else{
				out<<name<<" could not reserve a seat!"<<endl;
				return;
			}
	}
	else{
		out<<name<<" could not reserve a seat!"<<endl;
		return;
	}
}

void cancel_reservation(unordered_map <string, unordered_map<string, unordered_map < string, string>>>&stadium,unordered_map <string, vector<string>>&reservations,unordered_map <string, que>&heaplist,string name, ofstream &out){
	if(reservations.find(name) != reservations.end()){
		stadium[reservations[name][0]][reservations[name][1]][reservations[name][2]]="---";
		heaplist[reservations[name][1]].decrease(reservations[name][0]);
		reservations.erase(name);
		out<<"Cancelled the reservation of "<< name << endl;
	}
	else{
		out<<"Could not cancel the reservation for "<<name<<"; no reservation found!" << endl;
	}
}

int main(){
	ifstream file;
	ofstream out;
	string filename="inputs.txt", out_file = "output.txt";//input and output files
	string line1;
	string word;
	file.open(filename.c_str());
	out.open(out_file.c_str());
	string function;

	while(file.fail()){//if it cant open the file
		file.clear();
		cout<<"Cannot find a file named "<<filename<< endl;
		return 0;
	}
	unordered_map <string, unordered_map<string, unordered_map < string, string>>>stadium;//unordered_map stadium
	vector<string>blocks,rows;//block and row vectors
	unordered_map <string, vector<string>>reservations;//unordered map for who reserved where
	unordered_map <string, que>heaplist;//priority heaplist for unordered map row and contains datas



	getline(file,line1);
	stringstream ss1(line1);
	while(ss1>>word){
		stadium[word];
		blocks.push_back(word);
	}

	getline(file,line1);
	stringstream ss2(line1);
	while(ss2>>word){
		int i=0;
		while(i<blocks.size()){
			stadium[blocks[i]][word];
			i++;
		}
		rows.push_back(word);
	}

	getline(file,line1);
	stringstream ss3(line1);
	int col_num;
	ss3>>col_num;

	for(int i=0;i<blocks.size();i++){

		for(int b=0;b<rows.size();b++){

			for(int j=0;j<col_num;j++){
				stadium[blocks[i]][rows[b]][to_string(j)]="---";//fill the stadium by ---
			}
		}
	}

	for(int i=0;i<rows.size();i++){
		heaplist[rows[i]];
		heaplist[rows[i]].set_heap(blocks);//construct unordered map for rows and heap with block vector
	}

	while(!file.eof()){
		if(getline(file,line1)){
			if(line1=="")
			{
				return 0;
			}
			stringstream ss4(line1);
			ss4>>function;
			if(function=="print"){//if function is print
				print(stadium,blocks,rows,col_num, out);
			}
			else if(function=="reserve_seat"){//if function is reserve_seat
				string name;
				string block;
				string row;
				string col;
				ss4>>name>>block>>row>>col;
				reserve_seat(stadium,name,block,row,col,reservations,heaplist, out);//call reserve_seat function
			}
			else if(function=="get_seat"){//if function is get_seat
				string name;
				ss4>>name;
				get_seat(name,reservations, out);
			}
			else if(function=="reserve_seat_by_row"){//if function is reserve_seat_by_row
				string name;
				string row;
				ss4>>name>>row;
				reserve_seat_by_row(name,row,stadium,reservations,heaplist,col_num, out);//call reserve_seat_by_row function

			}
			else if(function=="cancel_reservation"){//if function is cancel_reservation
				string name;
				ss4>>name;
				cancel_reservation(stadium,reservations,heaplist,name, out);//call cancel_reservation function
			}
		}
	}
	file.close();
	out.close();
	return 0;
}
