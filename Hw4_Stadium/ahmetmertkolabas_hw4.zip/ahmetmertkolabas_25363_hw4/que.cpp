#include <string>
#include "que.h"
#include <iostream>
using namespace std;

que::que(){//default constructor

}


que::~que(){//destructor

}

void que::set_heap(vector<string>blocks){//build the heap calls elements for all unordered map elements
	heap.resize(blocks.size()+1);
	currentSize = 0;
	for(int i=1;i<=blocks.size();i++){
		heap[i].value=0;
		heap[i].label=i;
		heap[i].blockname=blocks[i-1];
		locations[blocks[i-1]];
		locations[blocks[i-1]]=i;
		currentSize++;

	}
}


void  que::increase(string blockname){//increase the element in the heaplist

	int pos=locations[blockname];
	heap[pos].value++;
	percolateDown(pos);//call percolatedown
}

void que::decrease(string blockname){//decrease the element in the heaplist

	int pos=locations[blockname];//find the position in heaplist
	heap[pos].value--;
	int hole=pos;
	int value2=heap[pos].value;
	int label2=heap[pos].label;
	string block2=heap[pos].blockname;



	for( ; hole > 1;hole=hole/2 ){//percolate up the heap
		if(value2<heap[ hole/2].value)
		{
			heap[ hole ] = heap[ hole/2];
			locations[heap[hole].blockname] = hole;
		}
		else if(value2==heap[ hole/2].value && label2<heap[hole/2].label){
			heap[ hole ] = heap[ hole/2];
			locations[heap[hole].blockname] = hole;
		}
	}
	heap[hole].label = label2;
		heap[hole].value = value2;
		heap[hole].blockname=block2;
		locations[heap[hole].blockname] =pos;

}

string que::get_min(){//return the first elementin the heap
	return heap[1].blockname;
}


void que::percolateDown( int hole )//percolate down the heap according to the hole index
{
	int child;
	int tmp_val = heap[ hole ].value; 
	int tmp_lab = heap[ hole ].label;
	string tmp_block= heap[hole].blockname;

	for( ; hole*2 <= currentSize; hole = child ){

		child = hole*2;// child is the minimum of the children


		if( child != currentSize && heap[ child + 1 ].value < heap[ child ].value )// child is the minimum of the children

			child++;
		else if(child != currentSize && heap[ child+1 ].value==heap[ child ].value && heap[ child + 1 ].label < heap[ child ].label){//if the values are same then look at label 
			child++;
		}

		if( heap[ child ].value < tmp_val || (heap[ child ].value==tmp_val && heap[ child ].label < tmp_lab)){//if the values are same then look at label 

			heap[ hole ].value = heap[ child ].value; // change hole value with heap[child].value
			heap[hole].label = heap[child].label;// change hole value with heap[child].label
			heap[hole].blockname = heap[child].blockname;// change hole value with heap[child].blockname
			locations[heap[hole].blockname] =hole;//place hole index in locations according to the blockname
		}

		else
			break;
	}
	heap[ hole ].value = tmp_val; // place tmp in its final position
	heap[hole].label = tmp_lab;// place tmp in its final position
	heap[hole].blockname =tmp_block;// place tmp in its final position
	locations[heap[hole].blockname] =hole;//place hole index in locations according to the blockname
}


