#ifndef QUE_H
#define QUE_H
#include <vector>
#include <unordered_map> 
using namespace std;

struct queueObject{//struct of heaplist elements
	int value;
	int label;
	string blockname;
};

class que
{
public:

	que();
	~que();
	void increase(string);//increase the element to the heaplist
	void set_heap(vector<string>);//build the heap
	string get_min();//return the first index of the heaplist
	void decrease(string);//decrease the element and if needed change the locations index 


private:
	int currentSize;//size of the heap
	vector<queueObject> heap;//class object
	unordered_map <string,int>locations;//unordered map of locations
	void percolateDown( int hole );//take a index which the element is in and percolateDown it and sort
}; 
#endif